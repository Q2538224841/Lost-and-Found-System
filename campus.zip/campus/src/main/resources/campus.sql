/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.7.25 : Database - campus
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`campus` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `campus`;

/*Table structure for table `comment_tb` */

DROP TABLE IF EXISTS `comment_tb`;

CREATE TABLE `comment_tb` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `uid` int(255) DEFAULT NULL COMMENT '用户id',
  `create_time` date DEFAULT NULL COMMENT '评论时间',
  `item_id` int(255) DEFAULT NULL COMMENT '实物id',
  `content` varchar(30) DEFAULT NULL COMMENT '评论内容',
  `deleted` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id_comment` (`item_id`),
  CONSTRAINT `item_id_comment` FOREIGN KEY (`item_id`) REFERENCES `items_tb` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `comment_tb` */

insert  into `comment_tb`(`id`,`uid`,`create_time`,`item_id`,`content`,`deleted`) values 
(1,1,'2022-09-21',1,'222',0),
(2,1,'2022-09-21',1,'测试',NULL),
(3,1,'2022-09-21',6,'在操场',NULL),
(4,1,'2022-09-21',6,'222',NULL),
(5,1,'2022-09-21',2,'222',NULL);

/*Table structure for table `items_tb` */

DROP TABLE IF EXISTS `items_tb`;

CREATE TABLE `items_tb` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(20) NOT NULL COMMENT '物品名称',
  `description` varchar(100) NOT NULL COMMENT '物品描述',
  `create_time` date DEFAULT NULL COMMENT '创建时间',
  `uid` int(255) DEFAULT NULL COMMENT '用户id',
  `view_count` int(255) DEFAULT NULL COMMENT '浏览次数',
  `comment_count` int(255) DEFAULT NULL COMMENT '评论条数',
  `pic` varchar(255) DEFAULT NULL COMMENT '实物图片',
  `deleted` int(1) DEFAULT NULL,
  `tag` varchar(10) DEFAULT NULL COMMENT '分类标签',
  `flag` varchar(4) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_items` (`uid`),
  CONSTRAINT `user_id_items` FOREIGN KEY (`uid`) REFERENCES `user_tb` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `items_tb` */

insert  into `items_tb`(`id`,`name`,`description`,`create_time`,`uid`,`view_count`,`comment_count`,`pic`,`deleted`,`tag`,`flag`,`contact`) values 
(1,'手机','手机找到了','2022-09-20',1,21,1,'',1,'电子设备','寻找失主','1111'),
(2,'去去去','请求请求群群群','2022-09-20',1,3,1,'',1,'书籍','寻回物品',NULL),
(6,'耳机','谁捡到了','2022-09-20',1,6,2,'http://localhost:8089/images/2022.09.20/efccac34-bd43-40fa-97a2-b967bea82697.jpg',1,'电子设备','寻回物品',NULL),
(9,'手机','手机谁的','2022-09-21',1,1,0,'http://localhost:8089/images/2022.09.21/5fc79dfc-2e5e-4215-ac89-faed86d8d6a7.jpg',1,'电子设备','寻找失主','qq:123456789');

/*Table structure for table `login_log_tb` */

DROP TABLE IF EXISTS `login_log_tb`;

CREATE TABLE `login_log_tb` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ip` varchar(32) DEFAULT NULL COMMENT 'ip地址',
  `address` varchar(32) DEFAULT NULL COMMENT 'ip属地',
  `login_time` date DEFAULT NULL COMMENT '登录时间',
  `deleted` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `login_log_tb` */

insert  into `login_log_tb`(`id`,`ip`,`address`,`login_time`,`deleted`) values 
(2,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-20',1),
(5,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(6,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(7,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(8,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(9,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(10,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(11,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(12,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(13,'0:0:0:0:0:0:0:1','\n\n陕西省西安市 移通\n','2022-09-21',1),
(14,'111.19.45.46','\n\n陕西省西安市 移通\n','2022-09-21',1);

/*Table structure for table `user_tb` */

DROP TABLE IF EXISTS `user_tb`;

CREATE TABLE `user_tb` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `username` varchar(10) NOT NULL COMMENT '用户名',
  `gender` int(1) DEFAULT NULL COMMENT '性别，0：男，1：女',
  `create_date` date NOT NULL COMMENT '注册日期',
  `email` varchar(30) NOT NULL COMMENT '邮箱',
  `phone` varchar(11) NOT NULL COMMENT '手机号',
  `signature` varchar(20) DEFAULT NULL COMMENT '个人签名',
  `photo` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `score` int(255) DEFAULT NULL COMMENT '用户积分',
  `deleted` int(1) DEFAULT NULL COMMENT '标记删除，0：删除,1:未删除',
  `levels` int(1) DEFAULT NULL COMMENT '0：用户，1：管理员',
  `salt` int(6) NOT NULL COMMENT '加密',
  `password` varchar(32) NOT NULL COMMENT '密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `user_tb` */

insert  into `user_tb`(`id`,`username`,`gender`,`create_date`,`email`,`phone`,`signature`,`photo`,`score`,`deleted`,`levels`,`salt`,`password`) values 
(1,'林邵晨',0,'2022-09-20','1551483075@qq.com','17829805912','这个人很懒，什么也没有留下！','https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',40,1,1,275772,'de6ada031f3c8d2468e95f9d1874a5e8');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
