//package campus.utils;
//
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
//import com.baomidou.mybatisplus.core.toolkit.StringUtils;
//import org.apache.http.HttpEntity;
//import org.apache.http.client.methods.CloseableHttpResponse;
//import org.apache.http.client.methods.HttpGet;
//import org.apache.http.impl.client.CloseableHttpClient;
//import org.apache.http.impl.client.HttpClients;
//import org.apache.http.util.EntityUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import static hotel.constants.CommonConstants.KEY;
//
///**
// * 获取经纬度
// */
//public class AddressUtils {
//
//    private static final Logger log = LoggerFactory.getLogger(AddressUtils.class);
//
//    public static Addr getLatAndLngByAddr(String s) {
//
//        try {
//            CloseableHttpClient client = HttpClients.createDefault();
//            String url = "http://api.tianditu.gov.cn/geocoder?ds=%7B'keyWord':'" +s+ "'%7D&tk="+KEY;
//            HttpGet get = new HttpGet(url);
//            CloseableHttpResponse response = client.execute(get);
//            HttpEntity entity = response.getEntity();
//            String info = EntityUtils.toString(entity, "UTF-8");
//            if (StringUtils.isNotBlank(info)) {
//                JSONObject resultJson = JSON.parseObject(info);
//                if ("ok".equals(resultJson.get("msg"))) {
//                    JSONObject locationObj = (JSONObject) resultJson.get("location");
//                    //纬度
//                    String latitude = locationObj.get("lat") + "";
//                    //经度
//                    String longitude = locationObj.get("lon") + "";
//                    Addr addr = new Addr(longitude, latitude);
//                    response.close();
//                    return addr;
//                }
//            }
//            return null;
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//
////    public static void main(String[] args) {
////        System.out.println(AddressUtils.getLatAndLngByAddr("陕西省西安市"));
////    }
//
//}
