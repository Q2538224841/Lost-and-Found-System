package campus.domain.Res;

import io.swagger.annotations.Api;
import lombok.Data;

@Api("返回结果")
@Data
public class ResModel {

    private boolean flag;
    private String msg;
    private Object data;

    public ResModel(boolean flag, String msg, Object data) {
        this.flag = flag;
        this.msg = msg;
        this.data = data;
    }
}
