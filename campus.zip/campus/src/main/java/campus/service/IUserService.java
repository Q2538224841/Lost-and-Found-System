package campus.service;

import campus.domain.Res.ResModel;
import campus.domain.User;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

public interface IUserService extends IService<User> {
    User register(User user);

    ResModel login(User user, String addr);

    ResModel getActivationCode(User user);

    User selectOne(Integer id);

    User updateUser(User user);

    ResModel replaceAvator(MultipartFile file, HttpServletRequest request) throws IOException;

    ResModel updatePassword(User user);

    IPage<User> getScore(Integer currentPage, Integer pageSize);

    IPage<User> getPage(Integer currentPage, Integer pageSize, User user);
}
