package campus.service.impl;

import campus.domain.Item;
import campus.domain.User;
import campus.mapper.ItemMapper;
import campus.service.IUserService;
import campus.service.ItemService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

import static campus.constants.NumberConstants.ONE;
import static campus.constants.NumberConstants.ZERO;

@Service
public class ItemServiceImpl extends ServiceImpl<ItemMapper, Item> implements ItemService {

    @Resource
    private ItemMapper itemMapper;
    @Resource
    private IUserService userService;

    @Override
    public boolean issue(Item item) {
        item.setViewCount(ZERO);
        item.setCommentCount(ZERO);
        item.setDeleted(ONE);
        if(item.getPic()==null){
            item.setPic("");
        }
        return save(item);
    }

    @Override
    public List<Item> getList(Integer id) {
        QueryWrapper<Item> wrapper = new QueryWrapper<>();
        wrapper.eq(true,"uid",id);
        List<Item> items = list(wrapper);
        User user = userService.selectOne(id);
        for (Item item : items) {
            item.setUser(user);
        }
        return items;
    }

    @Override
    public IPage<Item> getPage(Integer page, Integer size, Item item) {
        Page<Item> page1 = new Page<>(page,size);
        LambdaQueryWrapper<Item> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(!"全部".equals(item.getTag()),Item::getTag,item.getTag());
        Page<Item> itemPage = itemMapper.selectPage(page1, wrapper);
        List<Item> records = itemPage.getRecords();
        for (Item record : records) {
            User user = userService.selectOne(record.getUid());
            record.setUser(user);
        }
        return itemPage;
    }

    @Override
    public Item getItem(Integer id) {
        Item item = getById(id);
        User user = userService.selectOne(item.getUid());
        item.setUser(user);
        return item;
    }

    @Override
    public IPage<Item> getByPage(Integer page, Integer size, Item item) {
        Page<Item> page1 = new Page<>(page,size);
        LambdaQueryWrapper<Item> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(item.getName()!=null,Item::getName,item.getName());
        Page<Item> itemPage = itemMapper.selectPage(page1, wrapper);
        return itemPage;
    }
}
