package campus.service.impl;

import campus.domain.Log;
import campus.domain.Res.ResModel;
import campus.domain.User;
import campus.mapper.LogMapper;
import campus.mapper.UserMapper;
import campus.service.IUserService;
import campus.utils.EmailUtils;
import campus.utils.MD5Utils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static campus.constants.CommonConstants.PATH;
import static campus.constants.CommonConstants.PHOTO;
import static campus.constants.ExceptionConstants.*;
import static campus.constants.NumberConstants.ONE;
import static campus.constants.NumberConstants.ZERO;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

    @Resource
    private UserMapper userMapper;

    @Resource
    private LogMapper logMapper;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    public HttpServletRequest request;

    @Value("${file-save-path}")
    private String fileSavePath;

    /**
     * 用户注册
     * @param user
     * @return
     */
    @Override
    public User register(User user) {
       synchronized (this){
           String code = redisTemplate.opsForValue().get(user.getEmail());
           if (!user.getCode().equals(code) || user.getEmail()==null || user.getPassword()==null){
               throw new RuntimeException(PRIMARY_KEY_NULL);
           }
           QueryWrapper<User> wrapper = new QueryWrapper<>();
           wrapper.eq(true,"email",user.getEmail());
           User one = userMapper.selectOne(wrapper);
           if (one!=null){
               return user;
           }
           long time = new Date().getTime();
           String salt=Long.toString(time).substring(7,13);
           user.setSalt(salt);
           user.setPhoto(PHOTO);
           user.setLevels(ZERO);
           user.setDeleted(ONE);
           user.setCreateDate(new Date());
           user.setScore(ZERO);
           user.setGender(ZERO);
           user.setPhone("");
           user.setSignature("这个人很懒，什么也没有留下！");
           String password = MD5Utils.encryption(user.getPassword() + salt);
           user.setPassword(password);
           return save(user)==true?null:user;
       }
    }

    /**
     * 用户登录
     * @param user
     * @param addr
     * @return
     */
    @Override
    public ResModel login(User user, String addr) {
        if (user.getPassword()==null || user.getEmail()==null){
            throw new RuntimeException(PRIMARY_KEY_NULL);
        }
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq(true,"email",user.getEmail());
        User one = userMapper.selectOne(wrapper);
        String ps = MD5Utils.encryption(user.getPassword() + one.getSalt());
        if (one.getDeleted()==ONE && ps.equals(one.getPassword())){
            //获取ip对应的地理位置
            String url=PATH+addr;
            String address = restTemplate.getForObject(url, String.class);
            String s = address.substring(2, 8);
            Log log = new Log();
            log.setIp(addr);
            log.setAddress(address);
            log.setLoginTime(new Date());
            log.setDeleted(ONE);
            logMapper.insert(log);
            return new ResModel(true,SUCCESS,one);
        }
        return new ResModel(false,ERROR,user);
    }

    /**
     * 获取邮箱激活码
     * @return
     */
    @Override
    public ResModel getActivationCode(User user) {
        if (user.getEmail()==null){
            return null;
        }
        long time = new Date().getTime();
        String code=Long.toString(time).substring(7,13);
        redisTemplate.opsForValue().set(user.getEmail(),code, Duration.ofMinutes(10));
        EmailUtils utils = new EmailUtils(user.getEmail(),code);
        utils.run();
        return new ResModel(true,SUCCESS,null);
    }

    /**
     * 根据id查询用户
     * @param id
     * @return
     */
    @Override
    public User selectOne(Integer id) {
        if (id==null){
            throw new RuntimeException(PRIMARY_KEY_NULL);
        }
        return getById(id);
    }

    /**
     * 修改用户
     * @param user
     * @return
     */
    @Override
    public User updateUser(User user) {
        synchronized (this){
            if (user.getId()==null){
                throw new RuntimeException(PRIMARY_KEY_NULL);
            }
            boolean b = updateById(user);
            return b==true? user:null;
        }
    }

    /**
     * 更换头像
     * @param file
     * @param request
     * @return
     */
    @Override
    public ResModel replaceAvator(MultipartFile file, HttpServletRequest request) throws IOException {
        //获取文件的名字
        String originName = file.getOriginalFilename();
        //判断文件类型
        if(!originName.endsWith(".jpg")) {
            return new ResModel(false,ERROR,originName);
        }
        //给上传的文件新建目录
        SimpleDateFormat sdf = new SimpleDateFormat("/yyyy.MM.dd/");
        String format = sdf.format(new Date());
        String realPath = fileSavePath + format;
        //若目录不存在则创建目录
        File folder = new File(realPath);
        if(!folder.exists()) {
            folder.mkdirs();
        }
        //给上传文件取新的名字，避免重名
        String newName = UUID.randomUUID().toString() + ".jpg";
        //生成文件，folder为文件目录，newName为文件名
        file.transferTo(new File(folder,newName));
        //生成返回给前端的url
        String url = request.getScheme() + "://" + "localhost:8089"+"/images"+ format + newName;
        return new ResModel(true,SUCCESS,url);
    }

    /**
     * 修改密码
     * @param user
     * @return
     */
    @Override
    public ResModel updatePassword(User user) {
        String code = redisTemplate.opsForValue().get(user.getEmail());
        if (user.getId()==null || !user.getCode().equals(code)){
            throw new RuntimeException(PRIMARY_KEY_NULL);
        }
        long time = new Date().getTime();
        String salt=Long.toString(time).substring(7,13);
        String s = MD5Utils.encryption(user.getPassword()+salt);
        user.setPassword(s);
        user.setSalt(salt);
        boolean b = updateById(user);
        return new ResModel(b,b==true? SUCCESS:ERROR,null);
    }

    @Override
    public IPage<User> getScore(Integer currentPage, Integer pageSize) {
        Page<User> page = new Page<>(currentPage,pageSize);
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(true,User::getScore);
        return userMapper.selectPage(page,wrapper);
    }

    @Override
    public IPage<User> getPage(Integer currentPage, Integer pageSize, User user) {
        Page<User> page = new Page<>(currentPage,pageSize);
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(user.getUsername()!=null,User::getUsername,user.getUsername());
        return userMapper.selectPage(page,wrapper);
    }
}
