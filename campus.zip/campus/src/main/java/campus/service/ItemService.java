package campus.service;

import campus.domain.Item;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface ItemService extends IService<Item> {
    boolean issue(Item item);

    List<Item> getList(Integer id);

    IPage<Item> getPage(Integer page, Integer size, Item item);

    Item getItem(Integer id);

    IPage<Item> getByPage(Integer page, Integer size, Item item);
}
