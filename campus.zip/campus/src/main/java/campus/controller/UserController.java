package campus.controller;

import campus.advice.BaseResponse;
import campus.domain.Res.ResModel;
import campus.domain.User;
import campus.service.IUserService;
import campus.utils.MD5Utils;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.models.auth.In;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import static campus.constants.CommonConstants.PHOTO;
import static campus.constants.NumberConstants.ONE;
import static campus.constants.NumberConstants.ZERO;


@Api("个人信息")
@BaseResponse
@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController {


    @Resource
    private IUserService userService;


    @PostMapping(path = "/register",produces = "application/json")
    @ApiOperation("用户注册")
    public User register(@RequestBody User user){
        return userService.register(user);
    }

    @PostMapping(path = "/login",produces = "application/json")
    @ApiOperation("用户登录")
    public ResModel login(@RequestBody User user, HttpServletRequest request){
        return userService.login(user,request.getRemoteAddr());
    }

    @PostMapping(path = "/upd",produces = "application/json")
    @ApiOperation("修改密码")
    public ResModel updatePassword(@RequestBody User user){
        return userService.updatePassword(user);
    }

    @PostMapping("/code")
    @ApiOperation("获取邮箱激活码")
    public ResModel getActivationCode(@RequestBody User user){
        return userService.getActivationCode(user);
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "根据id查询用户")
    public User selectOne(@PathVariable @ApiParam(value = "用户id") Integer id){
        return userService.selectOne(id);
    }

    @DeleteMapping("/{id}")
    public boolean delete(@PathVariable Integer id){
        return userService.removeById(id);
    }

    @PostMapping("/deleteAll")
    public boolean delete(@RequestBody List<Integer> ids){
        return userService.removeByIds(ids);
    }

    @PutMapping(path = "",produces = "application/json")
    @ApiOperation(value = "修改用户")
    public User updateUser(@RequestBody User user){
        return userService.updateUser(user);
    }

    @PostMapping(path = "/avator",produces = "application/json")
    @ApiOperation("更换头像")
    public ResModel replaceAvator(@ApiParam("头像文件") MultipartFile file, HttpServletRequest request) throws IOException {
        return userService.replaceAvator(file,request);
    }

    @GetMapping("/score/{currentPage}/{pageSize}")
    public IPage<User> getScore(@PathVariable Integer currentPage, @PathVariable Integer pageSize){
        return userService.getScore(currentPage,pageSize);
    }

    @GetMapping("/page/{currentPage}/{pageSize}")
    public IPage<User> getPage(@PathVariable Integer currentPage, @PathVariable Integer pageSize,User user){
        return userService.getPage(currentPage,pageSize,user);
    }
    @PostMapping(path = "",produces = "application/json")
    public boolean saveUser(@RequestBody User user){
        long time = new Date().getTime();
        String salt=Long.toString(time).substring(7,13);
        user.setSalt(salt);
        user.setPhoto(PHOTO);
        user.setLevels(ZERO);
        user.setDeleted(ONE);
        user.setCreateDate(new Date());
        user.setScore(ZERO);
        user.setGender(ZERO);
        user.setPhone("");
        user.setSignature("这个人很懒，什么也没有留下！");
        String password = MD5Utils.encryption(user.getPassword() + salt);
        user.setPassword(password);
        return userService.save(user);
    }

}
