package campus.controller;

import campus.advice.BaseResponse;
import campus.domain.Com;
import campus.domain.Item;
import campus.domain.Log;
import campus.domain.User;
import campus.mapper.ComMapper;
import campus.mapper.LogMapper;
import campus.service.IUserService;
import campus.service.ItemService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@BaseResponse
@RestController
@CrossOrigin
@RequestMapping("/com")
public class ComController {

    @Autowired
    private IUserService userService;

    @Autowired
    private ItemService itemService;
    @Resource
    private ComMapper comMapper;

    @GetMapping("/{page}/{size}")
    public IPage<Com> page(@PathVariable Integer page, @PathVariable Integer size){
        return comMapper.selectPage(new Page<Com>(page,size),null);
    }

    @DeleteMapping("/{id}")
    public boolean deleteItem(@PathVariable Integer id){
        return comMapper.deleteById(id)>0;
    }

    @PostMapping("/all")
    public boolean deleteAllItem(@RequestBody List<Integer> ids){
        return comMapper.deleteBatchIds(ids)>0;
    }

    @PostMapping
    public boolean save(@RequestBody Com com){
        com.setCreateTime(new Date());
        User user = userService.getById(com.getUid());
        user.setScore(user.getScore()+10);
        userService.updateById(user);
        Item item = itemService.getById(com.getItemId());
        item.setViewCount(item.getViewCount()+1);
        item.setCommentCount(item.getCommentCount()+1);
        itemService.updateById(item);
        return comMapper.insert(com)>0;
    }

    @GetMapping("/{id}")
    public List<Com> page(@PathVariable Integer id){
        QueryWrapper<Com> wrapper = new QueryWrapper<>();
        wrapper.eq(true,"item_id",id);
        List<Com> comList = comMapper.selectList(wrapper);
        for (Com com : comList) {
            User user = userService.getById(com.getUid());
            com.setUser(user);
        }
        return comList;
    }
}
