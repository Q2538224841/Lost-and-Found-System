package campus.controller;

import campus.advice.BaseResponse;
import campus.domain.Item;
import campus.domain.Log;
import campus.mapper.LogMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@BaseResponse
@RestController
@CrossOrigin
@RequestMapping("/log")
public class LogController {

    @Resource
    private LogMapper logMapper;

    @GetMapping("/{page}/{size}")
    public IPage<Log> page(@PathVariable Integer page, @PathVariable Integer size){
        return logMapper.selectPage(new Page<Log>(page,size),null);
    }

    @DeleteMapping("/{id}")
    public boolean deleteItem(@PathVariable Integer id){
        return logMapper.deleteById(id)>0;
    }

    @PostMapping("/all")
    public boolean deleteAllItem(@RequestBody List<Integer> ids){
        return logMapper.deleteBatchIds(ids)>0;
    }
}
