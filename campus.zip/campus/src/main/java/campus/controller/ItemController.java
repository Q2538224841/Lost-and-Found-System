package campus.controller;

import campus.advice.BaseResponse;
import campus.domain.Item;
import campus.service.ItemService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api("物品信息")
@BaseResponse
@RestController
@CrossOrigin
@RequestMapping("/item")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @PostMapping(path = "/issue",produces = "application/json")
    public boolean issue(@RequestBody Item item){
        return itemService.issue(item);
    }

    @GetMapping("/{id}")
    public List<Item> getList(@PathVariable Integer id){
        return itemService.getList(id);
    }

    @GetMapping("/{page}/{size}")
    public IPage<Item> getPage(@PathVariable Integer page,@PathVariable Integer size,Item item){
        return itemService.getPage(page,size,item);
    }

    @GetMapping("/one/{id}")
    public Item getItem(@PathVariable Integer id){
        return itemService.getItem(id);
    }

    @GetMapping("/page/{page}/{size}")
    public IPage<Item> page(@PathVariable Integer page,@PathVariable Integer size,Item item){
        return itemService.getByPage(page,size,item);
    }

    @PutMapping
    public boolean updateItem(@RequestBody Item item){
        return itemService.updateById(item);
    }

    @DeleteMapping("/{id}")
    public boolean deleteItem(@PathVariable Integer id){
        return itemService.removeById(id);
    }

    @PostMapping("/all")
    public boolean deleteAllItem(@RequestBody List<Integer> ids){
        return itemService.removeByIds(ids);
    }

    @PostMapping(path = "/save",produces = "application/json")
    public boolean save(@RequestBody Item item){
        return itemService.save(item);
    }

    @GetMapping("/add/{id}")
    public boolean save(@PathVariable Integer id){
        Item item = itemService.getById(id);
        item.setViewCount(item.getViewCount()+1);
        return itemService.updateById(item);
    }


}
