package campus.constants;

/**
 * 共同属性
 */
public class CommonConstants {

    public final static String PHOTO="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png";
    public final static String EMAIL="1551483075@qq.com";
    //根据ip获取地理位置
    public final static String PATH="https://whois.pconline.com.cn/ip.jsp?ip=";
    //天地图key
    public final static String KEY="b5ed21e085f1e71e8bb6b0295026a523";
}
