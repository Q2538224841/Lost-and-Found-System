package campus.constants;

/**
 * 常量异常定义
 */
public class ExceptionConstants {

    public final static String PRIMARY_KEY_NULL="primary_key_isNull";
    public final static String PRIMARY_KEY_EXCEPTION="primary_key_illegal";
    public final static String SUCCESS="success";
    public final static String ERROR="error";

}
