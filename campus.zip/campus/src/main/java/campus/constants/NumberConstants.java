package campus.constants;

/**
 * 枚举数字
 */
public class NumberConstants {

    public final static int ZERO=0;
    public final static int ONE=1;
    public final static int TWO=2;
}
