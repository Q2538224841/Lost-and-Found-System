package campus.constants;

public class MqConstants {
    /**
     * 交换机
     */
    public final static String HOTEL_EXCHANGE = "hotel.topic";
    /**
     * 新增和修改队列
     */
    public final static String HOTEL_INSERT_QUEUE = "hotel.insert.queue";
    /**
     * 删除队列
     */
    public final static String HOTEL_DELETE_QUEUE = "hotel.delete.queue";
    /**
     * 新增和修改通配符
     */
    public final static String HOTEL_INSERT_KEY = "hotel.insert";
    /**
     * 删除通配符
     */
    public final static String HOTEL_DELETE_KEY = "hotel.delete";

}
