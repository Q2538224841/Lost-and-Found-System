import request from '../utils/request';

//批量删除list array转字符串
export async function deleteAll(params) {
    return request({
        url: '/log/all',
        method: 'post',
        data: params
    });
};


export async function getLogByPage(params) {
    return request({
        url: '/log/' +params.currentPage + '/' + params.pageSize,
        method: 'get'
    })
}



export async function delLog(id) {
    return request({
        url: '/log/' + id,
        method: 'delete'
    })
}